import 'package:flutter/material.dart';

class User {
  final String username;

  final String fromdate;
  final String todate;
  final String reason;

  User(this.username, this.fromdate, this.todate, this.reason);



}
