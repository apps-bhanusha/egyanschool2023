import 'package:ecom_desgin/constant/Colors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
class MyGoogeFont{
 static var mydmSans=GoogleFonts.dmSans(fontSize: 20.sp,color: AgentColor.appbarTextColor,);
 static var mydmSans1=GoogleFonts.dmSans(fontSize: 15.sp,color: AgentColor.appbarTextColor,);
 static var mydmSans2=GoogleFonts.dmSans(fontSize: 10.sp,color: AgentColor.appbarTextColor,);
}

