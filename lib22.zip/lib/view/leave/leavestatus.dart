import 'package:ecom_desgin/model/user.dart';
import 'package:ecom_desgin/model/user_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/cupertino.dart';

import 'package:google_fonts/google_fonts.dart';

import 'package:flutter/material.dart';

class LeaveStatus extends StatefulWidget {
  const LeaveStatus({Key? key}) : super(key: key);

  @override
  _LeaveStatusState createState() => _LeaveStatusState();
}

class _LeaveStatusState extends State<LeaveStatus> {
  int currentTab = 0;


  List<User> userList = [];


  @override
  Widget build(BuildContext context) {
    void addUserData(User user) {
      setState(() {
        userList.add(user);
      });
    }

    void showUserDialog() {
      showDialog(
        context: context,
        builder: (_) =>
         AlertDialog(
           content: AddUserDialog(
             addUserData,
           ),
           shape: RoundedRectangleBorder(
             borderRadius: BorderRadius.circular(10),
           ),
         ),

      );
    }

    return Scaffold(
      appBar: AppBar(
        // popup menu button
        actions: [
          PopupMenuButton<int>(
            itemBuilder: (context) => [
              // popupmenu item 1
              PopupMenuItem(
                value: 1,
                // row has two child icon and text.
                child: Row(
                  children: [
                    Icon(Icons.star),
                    SizedBox(
                      // sized box with width 10
                      width: 5,
                    ),
                    Text("home")
                  ],
                ),
              ),
              // popupmenu item 2
              PopupMenuItem(
                value: 2,
                // row has two child icon and text
                child: Row(
                  children: [
                    Icon(Icons.chrome_reader_mode),
                    SizedBox(
                      // sized box with width 10
                      width: 10,
                    ),
                    Text("About")
                  ],
                ),
              ),
            ],
            offset: Offset(0, 10),
            color: Color.fromARGB(255, 247, 247, 247),
            elevation: 2,
          ),
        ],

        title: Text('Leave Status'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: showUserDialog,
        child: Icon(Icons.add),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height * 0.75,
        child: ListView.builder(
          itemBuilder: (ctx, index) {
            return Card(
              margin: EdgeInsets.all(4),
              elevation: 8,
              child: Column(
                children: [
                  ListTile(
                    title: Text(
                      userList[index].username,
                      style: TextStyle(
                        fontSize: 22,
                      ),
                    ),
                    subtitle: Text(
                      userList[index].fromdate,
                      style: TextStyle(
                        fontSize: 22,
                      ),
                    ),
                    trailing: Text(
                      userList[index].todate,
                      style: TextStyle(
                        fontSize: 18,
                      ),
                    ),
                    leading:  Text(userList[index].reason),
                  ),

                ],
              ),
            );
          },
          itemCount: userList.length,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      // bottomNavigationBar: BottomAppBar(
      //   shape: CircularNotchedRectangle(),
      //   notchMargin: 10,
      //   color: Colors.green,
      //   child: Container(
      //     height: 60,
      //     child: Row(
      //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //       children: <Widget>[
      //
      //
      //       ],
      //     ),
      //   ),
      // ),
    );
  }
}
