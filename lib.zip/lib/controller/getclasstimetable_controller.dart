import 'dart:convert';
import 'package:ecom_desgin/constant/api_url.dart';
import 'package:get/get.dart';

import 'package:http/http.dart' as http;

class GetclassTimeTableController extends GetxController {

  List <dynamic> GetclassTimeTableControllerList = [].obs;
RxBool empty =true.obs;
  RxBool loadingGetclassTimeTable =false.obs;
  Future<String> GetclassTimeTableapi( company_key,id) async {

    var body = json.encode({
      "company_key":company_key,
      "id": id
    });
    final urlapi = Uri.parse(ApiUrl.baseUrl+ApiUrl.getclassTimeTableUrl);
    var response = await http.post(urlapi, body: body);
    if (response.statusCode == 200) {
      var  sdata = jsonDecode(response.body);
    
      GetclassTimeTableControllerList=[];
      GetclassTimeTableControllerList.add(sdata) ;
       loadingGetclassTimeTable.value=true;
      // print(GetschoolsettingControllerList[0]["response"]["total_discount_amount"]);
      if (sdata["status"] == true ) {
        empty.value =true;
        return "represhpage";
      }
      else  {
        empty.value =false;

         return "represhpage";
        print("invalid cccid");
      } }
    else {
        empty.value =false;
      print("School ID Invailid");
 return "represhpage";
      
    }
      
  }
}