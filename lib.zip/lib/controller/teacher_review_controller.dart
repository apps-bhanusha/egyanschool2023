import 'dart:convert';
import 'package:ecom_desgin/constant/api_url.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;

class TeacherRatingController extends GetxController {

  List <dynamic> TeacherRatingControllerList = [].obs;
  RxBool loadingTeacherRating =false.obs;
  RxBool isloading =false.obs;
  RxBool issumit =true.obs;

  get title => TeacherRatingControllerList;
  Future<String> TeacherRatingapi(company_key,staff_id,comment,rate,student_id) async {

    var body = json.encode({
      "company_key":company_key.toString(),
      "staff_id":staff_id.toString(),
      "comment":comment.toString(),
      "rate":rate.toString(),
      "student_id":student_id.toString()});
    final urlapi = Uri.parse(ApiUrl.baseUrl+ApiUrl.teacherratingUrl);
    var response = await http.post(urlapi, body: body);
  print("bbbbb");
    print(response.body);

    if (response.statusCode == 200) {
      print("A1");
      var  sdata = jsonDecode(response.body);
      if (sdata["status"] == "success" ) {
      print("A5");

        loadingTeacherRating.value=true;
        issumit.value=true;
        
           return "true";
      }
      else  {
         issumit.value=true;
        return "false";
         
        print("invalid cccid");
      }
       

       }
    else {
       issumit.value=true;
       return "false";
 

    }
  }
}