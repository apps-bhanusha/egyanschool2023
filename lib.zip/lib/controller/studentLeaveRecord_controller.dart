import 'dart:convert';
import 'package:ecom_desgin/constant/api_url.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../model/student_leave_model.dart';

class StudentLeaveRecordController extends GetxController {
 Rxn<StudentLeaveStatusModel> studentLeaveStatusModel = Rxn<StudentLeaveStatusModel>();
  List <dynamic> StudentLeaveRecordControllerList = [].obs;
  RxBool loadingStudentLeaveRecord =false.obs;
  RxBool isloading =false.obs;
  Future<String> StudentLeaveRecordapi(companyKey,id,) async {

    var body = json.encode({
      "company_key":companyKey,
      "id": id,

    });
    final urlapi = Uri.parse(ApiUrl.baseUrl+ApiUrl.studentLeaveRecordUrl);
    var response = await http.post(urlapi, body: body);
    if (response.statusCode == 200) {
      var  sdata = jsonDecode(response.body);
      StudentLeaveRecordControllerList=[];
      studentLeaveStatusModel.value=StudentLeaveStatusModel.fromJson(sdata);
      StudentLeaveRecordControllerList.add(sdata) ;
        // loadingStudentLeaveRecord.value=true;

      // print(GetschoolsettingControllerLexam_idist[0]["response"]["total_discount_amount"]);
      if (sdata["status"] == true ) {
        print("Leave Record true");
        loadingStudentLeaveRecord.value=true;
        return "refreshpage";
      }else  {
        
       isloading.value=true;
         return "refreshpage";
      } }
    else {

      print("School ID Invailid");
        return "refreshpage";
    }
  }
}