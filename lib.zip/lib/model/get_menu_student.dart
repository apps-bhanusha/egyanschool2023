// To parse this JSON data, do
//
//     final getMenuStd = getMenuStdFromJson(jsonString);

import 'dart:convert';

GetMenuStd getMenuStdFromJson(String str) => GetMenuStd.fromJson(json.decode(str));

String getMenuStdToJson(GetMenuStd data) => json.encode(data.toJson());

class GetMenuStd {
    GetMenuStd({
        required this.status,
        required this.message,
        required this.response,
    });

    bool status;
    String message;
    List<Response> response;

    factory GetMenuStd.fromJson(Map<String, dynamic> json) => GetMenuStd(
        status: json["status"],
        message: json["message"],
        response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
    };
}

class Response {
    Response({
        required this.moduleKey,
        required this.moduleName,
    });

    String moduleKey;
    String moduleName;

    factory Response.fromJson(Map<String, dynamic> json) => Response(
        moduleKey: json["module_key"],
        moduleName: json["module_name"],
    );

    Map<String, dynamic> toJson() => {
        "module_key": moduleKey,
        "module_name": moduleName,
    };
}
