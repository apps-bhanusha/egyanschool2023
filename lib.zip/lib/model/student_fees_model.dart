// To parse this JSON data, do
//
//     final studentFeesModel = studentFeesModelFromJson(jsonString);

import 'dart:convert';

StudentFeesModel studentFeesModelFromJson(String str) => StudentFeesModel.fromJson(json.decode(str));

String studentFeesModelToJson(StudentFeesModel data) => json.encode(data.toJson());

class StudentFeesModel {
  StudentFeesModel({
    required this.status,
    required this.message,
    required this.response,
  });

  bool status;
  String message;
  Response response;

  factory StudentFeesModel.fromJson(Map<String, dynamic> json) => StudentFeesModel(
    status: json["status"],
    message: json["message"],
    response: Response.fromJson(json["response"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "response": response.toJson(),
  };
}

class Response {
  Response({
    required this.totalAmount,
    required this.totalDiscountAmount,
    required this.totalDepositeAmount,
    required this.totalFineAmount,
    required this.totalBalanceAmount,
  });

  int totalAmount;
  int totalDiscountAmount;
  int totalDepositeAmount;
  int totalFineAmount;
  int totalBalanceAmount;

  factory Response.fromJson(Map<String, dynamic> json) => Response(
    totalAmount: json["total_amount"],
    totalDiscountAmount: json["total_discount_amount"],
    totalDepositeAmount: json["total_deposite_amount"],
    totalFineAmount: json["total_fine_amount"],
    totalBalanceAmount: json["total_balance_amount"],
  );

  Map<String, dynamic> toJson() => {
    "total_amount": totalAmount,
    "total_discount_amount": totalDiscountAmount,
    "total_deposite_amount": totalDepositeAmount,
    "total_fine_amount": totalFineAmount,
    "total_balance_amount": totalBalanceAmount,
  };
}
