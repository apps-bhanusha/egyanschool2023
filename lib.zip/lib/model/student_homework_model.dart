// To parse this JSON data, do
//
//     final studentHomeWorkModel = studentHomeWorkModelFromJson(jsonString);

import 'dart:convert';

StudentHomeWorkModel studentHomeWorkModelFromJson(String str) => StudentHomeWorkModel.fromJson(json.decode(str));

String studentHomeWorkModelToJson(StudentHomeWorkModel data) => json.encode(data.toJson());

class StudentHomeWorkModel {
  StudentHomeWorkModel({
    required this.status,
    required this.message,
    required this.response,
  });

  bool status;
  String message;
  List<Response> response;

  factory StudentHomeWorkModel.fromJson(Map<String, dynamic> json) => StudentHomeWorkModel(
    status: json["status"],
    message: json["message"],
    response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "response": List<dynamic>.from(response.map((x) => x.toJson())),
  };
}

class Response {
  Response({
    required this.id,
    required this.classId,
    required this.sectionId,
    required this.sessionId,
    required this.homeworkDate,
    required this.submissionDate,
    required this.staffId,
    required this.staffName,
    required this.subjectGroupSubjectId,
    required this.description,
    required this.createDate,
    required this.document,
    required this.submitDate,
    required this.evaluationDate,
    required this.responseClass,
    required this.section,
    required this.subjectId,
    required this.subjectName,
    required this.status,
  });

  String id;
  String classId;
  String sectionId;
  String sessionId;
  String homeworkDate;
  String submissionDate;
  String staffId;
  String staffName;
  String subjectGroupSubjectId;
  String description;
  String createDate;
  String document;
  String submitDate;
  String evaluationDate;
  String responseClass;
  String section;
  String subjectId;
  String subjectName;
  String status;

  factory Response.fromJson(Map<String, dynamic> json) => Response(
    id: json["id"],
    classId: json["class_id"],
    sectionId: json["section_id"],
    sessionId: json["session_id"],
    homeworkDate: json["homework_date"],
    submissionDate: json["submission_date"],
    staffId: json["staff_id"],
    staffName: json["staff_name"],
    subjectGroupSubjectId: json["subject_group_subject_id"],
    description: json["description"],
    createDate: json["create_date"],
    document: json["document"],
    submitDate: json["submit_date"]??"null",
    evaluationDate: json["evaluation_date"]??"null",
    responseClass: json["class"],
    section: json["section"],
    subjectId: json["subject_id"],
    subjectName: json["subject_name"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "class_id": classId,
    "section_id": sectionId,
    "session_id": sessionId,
    "homework_date":homeworkDate,
    "submission_date": submissionDate,
    "staff_id": staffId,
    "staff_name": staffName,
    "subject_group_subject_id": subjectGroupSubjectId,
    "description": description,
    "create_date": createDate,
    "document": document,
    "submit_date": submitDate,
    "evaluation_date": evaluationDate,
    "class": responseClass,
    "section": section,
    "subject_id": subjectId,
    "subject_name": subjectName,
    "status": status,
  };
}
