// To parse this JSON data, do
//
//     final studentLeaveStatusModel = studentLeaveStatusModelFromJson(jsonString);

import 'dart:convert';

StudentLeaveStatusModel studentLeaveStatusModelFromJson(String str) => StudentLeaveStatusModel.fromJson(json.decode(str));

String studentLeaveStatusModelToJson(StudentLeaveStatusModel data) => json.encode(data.toJson());

class StudentLeaveStatusModel {
  StudentLeaveStatusModel({
    required this.status,
    required this.message,
    required this.response,
  });

  bool status;
  String message;
  List<Response> response;

  factory StudentLeaveStatusModel.fromJson(Map<String, dynamic> json) => StudentLeaveStatusModel(
    status: json["status"],
    message: json["message"],
    response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "response": List<dynamic>.from(response.map((x) => x.toJson())),
  };
}

class Response {
  Response({
    required this.id,
    required this.studentSessionId,
    required this.fromDate,
    required this.toDate,
    required this.applyDate,
    required this.status,
    required this.createdAt,
    required this.docs,
    required this.reason,
    required this.approveBy,
    required this.approveDate,
    required this.requestType,
    required this.staffId,
    required this.leaveStatus,
    required this.firstname,
    required this.middlename,
    required this.lastname,
    required this.approvedByStaffName,
    required this.classId,
    required this.sectionId,
    required this.responseClass,
    required this.section,
  });

  String id;
  String studentSessionId;
  String fromDate;
  String toDate;
  String applyDate;
  String status;
  String createdAt;
  String docs;
  String reason;
  String approveBy;
  String approveDate;
  String requestType;
  String staffId;
  String leaveStatus;
  String firstname;
  String middlename;
  String lastname;
  String approvedByStaffName;
  String classId;
  String sectionId;
  String responseClass;
  String section;

  factory Response.fromJson(Map<String, dynamic> json) => Response(
    id: json["id"]??"null",
    studentSessionId: json["student_session_id"]??"null",
    fromDate: json["from_date"]??"null",
    toDate: json["to_date"]??"null",
    applyDate: json["apply_date"]??"null",
    status: json["status"]??"null",
    createdAt: json["created_at"]??"null",
    docs: json["docs"]??"null",
    reason: json["reason"],
    approveBy: json["approve_by"]??"null",
    approveDate: json["approve_date"]??"null",
    requestType: json["request_type"]??"null",
    staffId: json["staff_id"]??"null",
    leaveStatus: json["leave_status"]??"null",
    firstname: json["firstname"]??"null",
    middlename: json["middlename"]??"null",
    lastname: json["lastname"],
    approvedByStaffName: json["approved_by_staff_name"]??"null",
    classId: json["class_id"]??"null",
    sectionId: json["section_id"]??"null",
    responseClass: json["class"]??"null",
    section: json["section"]??"null",
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "student_session_id": studentSessionId,
    "from_date":fromDate,
    "to_date": toDate,
    "apply_date": applyDate,
    "status": status,
    "created_at": createdAt,
    "docs": docs,
    "reason": reason,
    "approve_by": approveBy,
    "approve_date": approveDate,
    "request_type": requestType,
    "staff_id": staffId,
    "leave_status": leaveStatus,
    "firstname": firstname,
    "middlename": middlename,
    "lastname": lastname,
    "approved_by_staff_name": approvedByStaffName,
    "class_id": classId,
    "section_id": sectionId,
    "class": responseClass,
    "section": section,
  };
}