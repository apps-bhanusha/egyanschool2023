

import 'package:ecom_desgin/Widgets/DropDown_widget.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/controller/getexamsSchedule1_controller.dart';
import 'package:ecom_desgin/controller/teacher_controller/student_list_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';


class ExamResultStudent extends StatefulWidget {
  final String title;
  final String exam_id;
  const ExamResultStudent({super.key,required this.title,required this.exam_id});



  @override
  State<ExamResultStudent> createState() => _ExamResultStudentState();
}

class _ExamResultStudentState extends State<ExamResultStudent> {

  GetexamsSchedule1Controller getexamview1 =
  Get.put(GetexamsSchedule1Controller());
  // GetexamsResultController GetexamsResult = Get.put(GetexamsResultController());
  StudentListController studentListController=Get.put(StudentListController());
  // int autohight=0;
  var company_key;
  var selectdata="Select Student";
  bool datafull=false;
  @override
  void initState() {
    studentListController.StudentListapi();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        title: Text("Result",style: MyGoogeFont.mydmSans),
      ),
      body: Container(
        margin: const EdgeInsets.symmetric(
          vertical: 1.0,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
              child: Container(
                color: Colors.blue,
                padding: const EdgeInsets.symmetric(horizontal: 5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      widget.title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white),
                    ),

                    IconButton(
                        icon: Container(
                          height: 30.0,
                          width: 30.0,
                          decoration: const BoxDecoration(
                            color: Colors.orange,
                            shape: BoxShape.circle,
                          ),
                          child: const Center(
                            child: Icon(
                              // expandFlag
                              //     ? Icons.keyboard_arrow_up
                              Icons.keyboard_arrow_down,
                              color: Colors.white,
                              size: 20.0,
                            ),
                          ),
                        ),
                        onPressed: () {

                        })


                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4.0 ,left:13).r,
              child: RichText(
                text: const TextSpan(
                  text: 'Student ID',
                  style: TextStyle(
                    color: Colors.black,
                  ),
                  children: <TextSpan>[
                    TextSpan(
                        text: '*',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.red)),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 18.0,right: 18.0 ).r,
              child: Container(
                height: 0.060.sh,
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.0,
                  ),
                ),
                child: Obx(()=>
                // studentListController.loadingStudentListdrop.value?
                  DropDownWidget(droph: 0.060.sh, selectText: selectdata, item: studentListController.studentList, isloading: studentListController.loadingStudentListdrop.value, xpand: true, empaty: "", onChange: (value) {
                                // print("You selected: $country");
                      selectdata=value!;
                      studentListController.GetexamsResultapi(selectdata,widget.exam_id);
                      studentListController.loadingStudentList1.value=false;
                      

                      setState(() {

                      });
                  },)

              
                ),
              ),
            ),
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
                child: ExpandableContainer(
                    autohight: 400,

                    child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                vertical: 0, horizontal: 5),
                            decoration: BoxDecoration(
                                border: Border.all(
                                    width: 0.3, color: Colors.grey),
                                color: const Color.fromARGB(
                                    255, 250, 254, 255)),
                            child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: const [
                                  Text("Subject"),
                                  Text("Passing Marks"),
                                  Text("Marks Obtained"),
                                  Text("Result"),
                                ]),
                          ),
                         Expanded(
                              child:Obx(()=>
                                studentListController.loadingStudentList1.value?studentListController.loadingStudentList.value? ListView.builder(
                                  itemBuilder:
                                      (BuildContext context,
                                      int index) {
                                    return Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              width: 0.3,
                                              color: Colors.grey),
                                          color: const Color
                                              .fromARGB(255,
                                              250, 254, 255)),
                                      child: ListTile(
                                        title: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .start,
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .spaceEvenly,
                                          children: [
                                            Text(
                                        '${studentListController.examResultModel.value?.response.examResult[index].minMarks}',
                                              style: const TextStyle(
                                                  fontWeight:
                                                  FontWeight
                                                      .bold,
                                                  color: Color
                                                      .fromARGB(
                                                      255,
                                                      0,
                                                      0,
                                                      0)),
                                            ),
                                            const SizedBox(
                                              width: 20,
                                            ),
                                            Text(
                                              '${studentListController.examResultModel.value?.response.examResult[index].getMarks}/${studentListController.examResultModel.value?.response.examResult[index].maxMarks}',
                                              style: const TextStyle(
                                                  fontWeight:
                                                  FontWeight
                                                      .bold,
                                                  color: Color
                                                      .fromARGB(
                                                      255,
                                                      0,
                                                      0,
                                                      0)),
                                            ),
                                          ],
                                        ),
                                        leading: Text(
                                            '${studentListController.examResultModel.value?.response.examResult[index].subjectName}',

                                        ),
                                        trailing: Text(
                                          '${studentListController.examResultModel.value?.response.examResult[index].result}',
                                        ),

                                      ));
                                  },
                                  itemCount: studentListController.examResultModel.value?.response.examResult
                                      .length??0,
                                ):const Center(child:Text("Data not Found") ):const Center(child: CircularProgressIndicator(color: Colors.blue,),)
                              )
                         )



                        ],
                      )


                    ))
          ],
        ),
      ),
    );
  }

}



class ExpandableContainer extends StatelessWidget {
  final bool expanded;
  final double collapsedHeight;
  final double expandedHeight;
  final Widget child;
  final double autohight;

  const ExpandableContainer({
    super.key,
    required this.child,
    this.collapsedHeight = 0.0,
    this.expandedHeight = 200,
    this.expanded = true,
    required this.autohight,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOut,
      width: screenWidth,
      height: expanded ? autohight : collapsedHeight,
      child: Container(
        child: child,
        // decoration:  BoxDecoration(border:  Border.all(width: 1.0, color: Color.fromARGB(255, 119, 127, 134))),
      ),
    );
  }
}