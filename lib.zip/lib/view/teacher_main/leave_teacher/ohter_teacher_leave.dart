import 'dart:async';

import 'package:ecom_desgin/Widgets/Leave_widget.dart';
import 'package:ecom_desgin/constant/Colors.dart';
import 'package:ecom_desgin/constant/date_format.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/controller/addstudentLeaveRecord_controller.dart';
import 'package:ecom_desgin/controller/studentLeaveRecord_controller.dart';
import 'package:ecom_desgin/controller/student_profile-Controller.dart';
import 'package:ecom_desgin/controller/teacher_controller/other_teacher_leave_controller.dart';
import 'package:ecom_desgin/controller/teacher_controller/staff_leave_type_controller.dart';
import 'package:ecom_desgin/view/leave/user_dialog.dart';
import 'package:ecom_desgin/view/teacher_main/leave_teacher/other_teacher_add_leave.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:flutter/material.dart';

class TeacherLeaveStatus extends StatefulWidget {
  const TeacherLeaveStatus({Key? key}) : super(key: key);

  @override
  _TeacherLeaveStatusState createState() => _TeacherLeaveStatusState();
}

class _TeacherLeaveStatusState extends State<TeacherLeaveStatus> {
  var company_key;
  var staff_id;
  var userfile;
  var id;
  // ignore: non_constant_identifier_names
  StaffLeaveRecordController staffLeaveRecord=Get.put(StaffLeaveRecordController());
  AddStudentLeaveRecordController AddStudentLeaveRecord =
  Get.put(AddStudentLeaveRecordController());
  final StudentProfileController studentProfileController = Get.put(StudentProfileController());
  StaffLeaveTypeController staffLeaveTypeController =Get.put(StaffLeaveTypeController());
  int currentTab = 0;
  DateTime today = DateTime.now();

  DateFormat currentDate=DateFormat.yMd();

  get dateStr => "${today.day}-${today.month}-${today.year}";
  var box = Hive.box("schoolData");
  @override
  void initState() {
    String dateStr = "${today.day}-${today.month}-${today.year}";

    super.initState();
    staffLeaveTypeController.staffLeaveTypeapi();
    id = box.get("student_id");
    company_key = box.get("company_key");
    staff_id=box.get("staff_id");
    staffLeaveRecord.StaffLeaveRecordapi(company_key,staff_id);
  }

  @override
  Widget build(BuildContext context) {
    void addUserData() {

    }

    void showUserDialog() {
      showDialog(
        context: context,

        builder: (_) =>

            AlertDialog(

              content: TeacherAddUserDialog(),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),

      );
    }

    return RefreshIndicator(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text('Staff Leave Status',style: MyGoogeFont.mydmSans),
     
        ),
        floatingActionButton: FloatingActionButton(
          onPressed:
            showUserDialog,


          child: Icon(Icons.add),
        ),//StudentLeaveRecord.loadingStudentLeaveRecord.value?
        body: Obx(
                () => staffLeaveRecord.isloading.value==false?staffLeaveRecord.staffLeaveRecordList.value?.response.length!=null?ListView.builder(
                  
              itemBuilder: (ctx, index) {
                return LeaveWidget(applyDate: staffLeaveRecord.staffLeaveRecordList.value?.response[index]["date"],
                 leave_from: staffLeaveRecord.staffLeaveRecordList.value?.response[index]["leave_from"], 
                 leave_to: staffLeaveRecord.staffLeaveRecordList.value?.response[index]["leave_to"],
                  status: staffLeaveRecord.staffLeaveRecordList.value?.response[index]["status"], 
                  applied_by: staffLeaveRecord.staffLeaveRecordList.value?.response[index]["applied_by"]
                  );


              },
              itemCount: staffLeaveRecord.isloading.value==false? staffLeaveRecord.staffLeaveRecordList.value?.response.length:0,
            ):const Center(child: CircularProgressIndicator(color: Colors.blue),):const Center(child: Text("Record Not Found"),)
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.miniCenterFloat,

      ),
      onRefresh: () async {
        AlwaysScrollableScrollPhysics();
        setState(() {

          staffLeaveRecord.StaffLeaveRecordapi(company_key,staff_id);
        });

      },
    );
  }
}
