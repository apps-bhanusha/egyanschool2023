import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../constant/font.dart';
import '../controller/student_profile-Controller.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({super.key});

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage>  {
  final StudentProfileController studentProfileController = Get.put(StudentProfileController());

Razorpay razorpay = Razorpay();
var amount=0;
@override
  void initState() {
    // TODO: implement initState
    super.initState();
     razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, handlePaymentErrorResponse);
                  razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, handlePaymentSuccessResponse);
                  razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, handleExternalWalletSelected);
  }
@override 
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    razorpay.clear();
  }

  @override
  Widget build(BuildContext context) {
   
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 217, 239, 252),
      appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text('Payment',style: MyGoogeFont.mydmSans),
         
        ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
   
    const SizedBox(height: 50,),
            Center(
              child: Card(
                        color: Color.fromARGB(255, 238, 238, 240),
                child: SizedBox(
                
                  width: 330,
                  height: 100,
                  child: Center(
                    child: SizedBox(
                     width: 200,
                             height: 40,
                      child: InkWell(
                        onTap: (){ 
                        print("Fee in pay ");
                       print(studentProfileController.studentProfileModel.value?.response.fee.totalBalanceAmount);
                            var options = {
                              'key': 'rzp_live_ILgsfZCZoFIKMb',
                              'amount': '${studentProfileController.studentProfileModel.value?.response.fee.totalBalanceAmount}00',
                              'name': studentProfileController.studentProfileModel.value?.response.name,
                              'description': "test",
                              'retry': {'enabled': true, 'max_count': 1},
                              'send_sms_hash': true,
                              'prefill': {'contact':studentProfileController.studentProfileModel.value?.response.mobileno, 
                              'email': studentProfileController.studentProfileModel.value?.response.email},
                              'external': {
                                'wallets': ['paytm']
                              }
                            };     
                           try {
                            
                              razorpay.open(options);
                           
                          
                           } catch (e) {
                             print("something Error");
                           }
                          },
                        child: Container(
                          alignment: Alignment.center,
                        decoration:BoxDecoration(
                          color: Colors.green,    
                          borderRadius: BorderRadius.circular(20)
                           ),
                           width: 140,
                           height: 40,
                          child: const Text("Pay Now",style: TextStyle(color: Colors.white,fontSize: 20)) ,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            
          ],
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  void handlePaymentErrorResponse(PaymentFailureResponse response){
    /*
    * PaymentFailureResponse contains three values:
    * 1. Error Code
    * 2. Error Description
    * 3. Metadata
    * */
    print("////////////////////////////////");
    print(response.message.toString());
    print(response.code.toString());
    print(response.error.toString());
    showAlertDialog(context, "Payment Failed", "Code: ${response.code}\nDescription: ${response.message}\nMetadata:${response.error.toString()}");
  }

  void handlePaymentSuccessResponse(PaymentSuccessResponse response){
    print(response);
    print(response.orderId);
    print(response.paymentId);
    print(response.signature);
    /*
    * Payment Success Response contains three values:
    * 1. Order ID
    * 2. Payment ID
    * 3. Signature
    * */
    showAlertDialog(context, "Payment Successful", "Payment ID: ${response.paymentId}");
  }
  void handleExternalWalletSelected(ExternalWalletResponse response){
    showAlertDialog(context, "External Wallet Selected", "${response.walletName}");
  }

  void showAlertDialog(BuildContext context, String title, String message){
    // set up the buttons
    Widget continueButton = ElevatedButton(
      child: const Text("Continue"),
      onPressed:  () {
        Navigator.pop(context);
      },
    );
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        continueButton,
      ],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}