import 'package:ecom_desgin/Widgets/DropDown_widget.dart';
import 'package:ecom_desgin/Widgets/TextFieldWidget.dart';
import 'package:ecom_desgin/Widgets/button_widget.dart';
import 'package:ecom_desgin/constant/Colors.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/controller/student_profile-Controller.dart';
import 'package:ecom_desgin/controller/teacher_by_Student_controller.dart';
import 'package:ecom_desgin/controller/teacher_review_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:smooth_star_rating_null_safety/smooth_star_rating_null_safety.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
class TeacherReview extends StatefulWidget {
  const TeacherReview({Key? key}) : super(key: key);

  @override
  State<TeacherReview> createState() => _TeacherReviewState();
}

class _TeacherReviewState extends State<TeacherReview> {
  TeacherRatingController teacherRatings=Get.put(TeacherRatingController());
  GetTeacherByStudentController teacherbystudentController=Get.put(GetTeacherByStudentController());
   final StudentProfileController studentProfileController =  Get.put(StudentProfileController());
 bool  selectteacher=false;
  var company_key;
  var staff_id;
var comment;
var  rate;
var student_id;
var title;
var show;
  List datesetall=[];//api
 var rating = 0.0;
  var box = Hive.box("schoolData");
  int _index = 0 ;
  @override
  void initState() {
    student_id = box.get("student_id");
    company_key = box.get("company_key");
    teacherbystudentController.loadingGetTeacherByStudent.value=false;
    teacherbystudentController.GetTeacherByStudentapi(company_key, studentProfileController.studentProfileModel.value?.response.studentId);


    super.initState();
  }

  var commentController = TextEditingController();
  String _selectdrop = "Select Teacher";
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        backgroundColor:Theme.of(context).primaryColor,
        title: Text('Teacher Reviews ',style: MyGoogeFont.mydmSans),
   
      ),
body: SingleChildScrollView(
  child:   Obx(
    () => teacherbystudentController.loadingGetTeacherByStudent.value? Column(
    
      children: [
  SizedBox(height: 0.050.sh,),
  Padding(
     padding: const EdgeInsets.only(left: 15,right: 15).r,
    child: DropDownWidget(droph: 0.050.sh, selectText: _selectdrop, item: teacherbystudentController.dropdata, isloading: true, xpand: true, empaty: "", onChange: (value) {
  
                    setState(() {
                      _selectdrop = value;
                      dataset(value);
                    });
    },),
  ),
        Column(
          children: [
  
            Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
       CustomTextField(hint: 'Description',controller: commentController,inputType: TextInputType.text,obscureText: false,onChange: (value){  },),

                  ],
                )),
    
            Center(
            child: Column(
              children: [
                SmoothStarRating(
                  rating: selectteacher?rating:0.0,
                  size: 40,
                  filledIconData: Icons.star,
                  halfFilledIconData: Icons.star_half,
                  defaultIconData: Icons.star_border,
                  starCount: 5,
                  allowHalfRating: false,
                  spacing: 2.0,
                  onRatingChanged: (value) {
                    setState(() {
                      rating = value;
                      rate=rating;
                    });
                  },
                ),
              // Text('${rating.toDouble()}'),
              ],
            ),
    
            ),
        Padding(
          padding:  const EdgeInsets.all(15),
          child: Center(
            child: teacherRatings.issumit.value? ButtonWidget(
                                  bh: 50,
                                  bw: 150,
                                  borderredius: 20,
                                  buttonColor: selectteacher? AgentColor.buttonColors:Colors.grey,
                                  child:const Text(
                                            "Submit",
                                            style: TextStyle(
                                                color: Colors.white, fontSize: 18),
                                          ),
        onTap:() {
            comment = commentController.text;
           if(selectteacher==true){
             if(rate!=null){
               teacherRatings.issumit.value=false;
            teacherRatings.TeacherRatingapi(company_key,staff_id,comment,rate,studentProfileController.studentProfileModel.value?.response.studentId).then((value) {
               if(value=="true"){
                  // commentController.text="";
                  Get.back();
                   Get.snackbar(
          "Rating Successfully Saved",
          "",
        duration: 5.seconds, // it could be any reasonable time, but I set it lo-o-ong
        snackPosition: SnackPosition.BOTTOM,

        isDismissible: true,
        backgroundColor: Colors.lightGreen,
        colorText: Colors.white,
        mainButton: TextButton(
            onPressed: Get.back,
            child: const Text(
                "Close"

            )),
      );
               }
            });
            }
            else{
            show="Please Enter comment";
            }
           }else{
             Get.snackbar(
        "Please Select Teacher"
        ,"",
        duration: 2.seconds, // it could be any reasonable time, but I set it lo-o-ong
        snackPosition: SnackPosition.BOTTOM,
        showProgressIndicator: true,

        isDismissible: true,
        backgroundColor: Colors.lightGreen,
        colorText: Colors.white,
        mainButton: TextButton(
            onPressed: Get.back,
            child: const Text(
              "Close"

            )),
      );
           }
          },

       ):ButtonWidget(
                                  bh: 50,
                                  bw: 150,
                                  borderredius: 20,
                                  buttonColor: AgentColor.buttonColors,
                                  child: const CircularProgressIndicator(color: Colors.white),
        onTap:() {
          },

                                        )
                                        
    //
          ),
        ),
    
    
      ],
    )
      ],
    ):Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Padding(
            padding: EdgeInsets.only(top: 300),
            child: CircularProgressIndicator(color: Colors.blue),
          )
        ],
      ),
    ),
  ),
),
    );

  }
  void dataset(datset1){


  // dropdata1 =dataset;
   for (var i=0; i<teacherbystudentController.GetTeacherByStudentControllerList[0]["response"].length; i++){
     print(datset1);
 if(datset1==teacherbystudentController.GetTeacherByStudentControllerList[0]["response"][i]["staff_name"].toString()){
  selectteacher=true;
   // datesetall.add(teacherbystudentController.GetTeacherByStudentControllerList[0]["response"][i]["staff_name"]);
   print(teacherbystudentController.GetTeacherByStudentControllerList[0]["response"][i]["staff_id"]);
  staff_id=teacherbystudentController.GetTeacherByStudentControllerList[0]["response"][i]["staff_id"];
 }

   }
}
}
