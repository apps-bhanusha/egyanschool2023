import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/view/teacher/upload_Content_dailog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class UploadContent extends StatefulWidget {
  const UploadContent({super.key});

  @override
  State<UploadContent> createState() => _UploadContentState();
}

class _UploadContentState extends State<UploadContent> {
List<String> countries = ["1st", "Russia", "USA", "China", "United Kingdom", "USA", "India"];
List<String> countries1 = ["A", "Russia", "USA", "China", "United Kingdom", "USA", "India"];
 bool value = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:   AppBar(
        backgroundColor: Colors.blue,
        title: Text("Upload Content",style: MyGoogeFont.mydmSans,),),

        
      body:  Column(
        children: [
          const SizedBox(height: 15,),
        Center(
          child: Container(
      
       width: 0.95.sw,
       height: 0.14.sh,
       decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
           BoxShadow(
                 blurRadius: 5,
                  color: Colors.grey
                )
                 ]
       ),
          child: Column(
            children: [
              Container(
                height: 10,
                width: 0.95.sw,
                color:Colors.blue
              ),

              const SizedBox( height: 35,),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const Text("Content List ",style:TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 20)),
               InkWell(
                  onTap: (){
                    Get.to(UploadContentDailog());
                  },
                  child: Container(
                    color: Colors.blue,
                    width: 100,
                    height: 30,
                    alignment: Alignment.center,
                  child: Text("Upload",style: TextStyle(color: Colors.white),),
                  ),
                )
            ],
           )
      
            ],
          ),
          ),
        ),
        
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
             Text("Content Title",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
             Text("Tyle",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
             Text("Date",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
             Text("Available for",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
             Text("Action",style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
            ],
          ),
        ) ,
             const SizedBox( height: 10,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

          children: [
           const SizedBox( width: 90, child: Text("Text Other",style: TextStyle(fontSize: 14),)),
           const SizedBox( width: 60,child: Text("syllabus",style: TextStyle(fontSize: 14),)),
           const SizedBox(width: 90,child: Text("30-01-2023",style: TextStyle(fontSize: 14),)),
           const SizedBox(width: 40,child: Text("1st",style: TextStyle(fontSize: 14),)),
           Row(
               children: const[
                 Icon(Icons.download),
                 SizedBox(
                  width: 15,
                 ),
                 Icon(Icons.close)
               ],
           ),
          ],
        ),
            ) ,
        ],
      )
    );
  }
}