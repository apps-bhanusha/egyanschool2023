
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';

import '../../constant/font.dart';
import '../../controller/About_Controller.dart';

class AboutEgyan extends StatefulWidget {
  const AboutEgyan({super.key});

  @override
  State<AboutEgyan> createState() => _AboutEgyanState();
}

class _AboutEgyanState extends State<AboutEgyan> {
   final AboutController aboutController= Get.put(AboutController()); 



@override
  void initState() {
    // TODO: implement initState
    super.initState();
     aboutController.isloading.value=false;
    aboutController.aboutEgyan();
  }
  @override
  Widget build(BuildContext context) {
    
     

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        title:  Text(
            "About E-Gyam",
              style: MyGoogeFont.mydmSans,
            ),),
      body:  SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            
         // ignore: prefer_const_constructors
        //  Obx(() => aboutController.isloading.value?  Text(Bidi.guardBracketInHtml("${aboutController.aboutModel.value?.response.description}")):Center(
        //   child: const Padding(
        // padding: EdgeInsets.only(top: 300),
        // child: CircularProgressIndicator(
        //   color:Colors.blue,
        // ),
        //   ),
        //  )),

          Obx(
            () => aboutController.isloading.value? Html( data:"${aboutController.aboutModel.value?.response.description}" , 
                  style: {
            // "hr":Style(
            //      padding: const EdgeInsets.all(0)
                  
            //  ),
             "br":Style(
                padding: const EdgeInsets.only(right: 50)
             )

                  },) :const Center(
                    child: Padding(
                          padding: EdgeInsets.only(top: 300),
                          child: CircularProgressIndicator(
                            color:Colors.blue,
                          ),
                            ),
                  ),
          ),
          ],
        ),
      )
        
    );
  }
}