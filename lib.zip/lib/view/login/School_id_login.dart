import 'package:ecom_desgin/Widgets/button_widget.dart';
import 'package:ecom_desgin/Widgets/footer_widget.dart';
import 'package:ecom_desgin/constant/Colors.dart';
import 'package:ecom_desgin/controller/school_id_controller.dart';
import 'package:ecom_desgin/main.dart';
import 'package:ecom_desgin/routes/routes.dart';
import 'package:ecom_desgin/view/login/Student_Login.dart';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';

class SimpleLogin extends StatefulWidget {

  @override

  _SimpleLoginState createState() => _SimpleLoginState();
}

class _SimpleLoginState extends State<SimpleLogin> {

  TextEditingController id = new TextEditingController();
  SchoolIdController all = SchoolIdController();

  List <SchoolIdController> _dataset = [];
  int _radioSelected = 0;
  late String _radioVal = "";
  int rediobutton = 0;

  String? string; // Nullable String

  void main() {
    var len = string!.length; // Runtime error: Null check operator used on a null value
  }
  @override
  void initState() {

    // Get.toNamed(
    //   'SimpleLogin',
    //   arguments: _radioVal,
    // );

    // Get.off(()=>SchoolIdController( _radioVal,));
    super.initState();

  }
  @override
  void dispose() {

    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Stack(
            children: <Widget>[
              ClipPath(
                  clipper: WaveClipper2(),
                  child:Container(
                    child: Column(),
                    width: MediaQuery.of(context).size.width,
                    height: 0.50.sh,
                    decoration: const BoxDecoration(
                        color: Colors.blue

                    ),
                  )
              ),
              ClipPath(
                clipper: WaveClipper3(),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 0.50.sh,

                  decoration: const BoxDecoration(
                      color: Colors.lightBlue
                  ),
                  child: Column(   children: <Widget>[
                    SizedBox(
                      height: 0.040.sh,
                    ),
                    InkWell(
                      child: CircleAvatar(
                        maxRadius: MediaQuery.of(context).size.width -
                            MediaQuery.of(context).size.width +
                            52,
                        backgroundImage:
                        const AssetImage("assets/images/appstore.png"),
                        // radius: 220,
                      ),

                    ),
                    SizedBox(
                      height: 0.030.sh,
                    ),
                    Text(
                    "E-GYAN",
                      style: GoogleFonts.dmSans(
                        fontStyle: FontStyle.normal,
                        fontSize: 35.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                  ),
                ),
              ),



            ],
          ),

          SizedBox(
            height: 0.040.sh,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 32).r,
            child: Material(
              elevation: 2.0,
              borderRadius: BorderRadius.all(Radius.circular(30)),
              child: TextField(
    controller:id,
                onChanged: (String value) {

                },
                cursorColor: Color.fromRGBO(32,64,81,1.0),
keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: " School Id",


                  prefixIcon: Material(
                    elevation: 0,
                    borderRadius: BorderRadius.all(Radius.circular(30)),
                    child: Icon(
                      Icons.account_circle_rounded,
                      color:  Color.fromRGBO(32,64,81,1.0),
                    ),
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 25,vertical: 13),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 0.035.sh,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Staff",
                style: GoogleFonts.dmSans(
                  fontStyle: FontStyle.normal,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,

                ),),

          Radio(
            value: 1,
            groupValue: _radioSelected,
            activeColor: Colors.blue,
            onChanged: (value) {
              setState(() {
                _radioSelected=value!;
                _radioVal="Teacher";
                print(value);
                rediobutton=value;
              });
            },
          ),
            Text("Parents",
                style: GoogleFonts.dmSans(
                  fontStyle: FontStyle.normal,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,

                ),),
              Radio(
                value: 2,
                groupValue: _radioSelected,
                activeColor: Colors.pink,
                onChanged: (value) {
                  setState(() {

                    _radioVal="parent";
                    _radioSelected=value!;

                    print(value);
                    rediobutton=value;

                  });

                },
              ),
              Text("Students",
                style: GoogleFonts.dmSans(
                  fontStyle: FontStyle.normal,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold,

                ),),
              Radio(
                value: 3,
                groupValue: _radioSelected,
                activeColor: Colors.pink,
                onChanged: (value) {
                  setState(() {
                    _radioVal="Student";
                    _radioSelected=value!;
                    rediobutton=value;
                  });

                },
              )
            ],
          ),
          SizedBox(
            height: 0.045.sh,
          ),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32).r,

              child:ButtonWidget(
                bh: 45,bw: 50,
              borderredius: 10,
              buttonColor: AgentColor.buttonColors,
              onTap: (){
            all.isloading.value=false;
                  all.apicall(id.text,rediobutton,context);

              },
                child:  Obx(
                    () => all.isloading.value ? Text(
                      "Next",
                      style: GoogleFonts.dmSans(
                        fontStyle: FontStyle.normal,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                  
                    ):const Center(child:  CircularProgressIndicator(color: Colors.white,)),
                  ),)

              ),
          SizedBox(height:0.05.sh),


        ],


      ),
    bottomNavigationBar:const FooterWidget() 
    );
  }
}


class WaveClipper2 extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0.0, size.height - 50);

    var firstEndPoint = Offset(size.width * .7, size.height - 40);
    var firstControlPoint = Offset(size.width * .25, size.height);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy,
        firstEndPoint.dx, firstEndPoint.dy);

    var secondEndPoint = Offset(size.width, size.height - 45);
    var secondControlPoint = Offset(size.width * 0.84, size.height - 50);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy,
        secondEndPoint.dx, secondEndPoint.dy);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}
class WaveClipper3 extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0.0, size.height - 50);

    var firstEndPoint = Offset(size.width * 0.49, size.height - 15 - 50);
    var firstControlPoint = Offset(size.width * .25, size.height - 60 - 50);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy,
        firstEndPoint.dx, firstEndPoint.dy);

    var secondEndPoint = Offset(size.width, size.height - 40);
    var secondControlPoint = Offset(size.width * 0.84, size.height);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy,
        secondEndPoint.dx, secondEndPoint.dy);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}