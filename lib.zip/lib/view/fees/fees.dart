import 'dart:async';

import 'package:ecom_desgin/Widgets/fees_widget.dart';
import 'package:ecom_desgin/constant/Colors.dart';
import 'package:ecom_desgin/constant/api_url.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/controller/student_profile-Controller.dart';
import 'package:ecom_desgin/controller/fees_controller.dart';
import 'package:ecom_desgin/controller/getschoolsetting_controller.dart';
import 'package:ecom_desgin/controller/student_login_controller.dart';
import 'package:ecom_desgin/controller/student_login_update_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:pie_chart/pie_chart.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
class Fees extends StatefulWidget {
  const Fees({Key? key}) : super(key: key);

  @override
  State<Fees> createState() => _FeesState();
}

class _FeesState extends State<Fees> {
    RefreshController _refreshController =
  RefreshController(initialRefresh: false);

  var schoolname;
  var session;
  var studentname;
  var studentclass;
  var studentsection;
  var studenttotalfees;
  var studentduefees;
  var studentpresent;
  var total_deposite_amount;
  var id;
  var company_key;
  var studentpro;
  var username;
  var password;
  bool dataMap1=false;
final UserNameController _allsetController = Get.put(UserNameController());
final FeeController all = Get.put(FeeController());
final GetSchoolSettingController _schoolsetting =
Get.put(GetSchoolSettingController());
  FeeController feeController=Get.put(FeeController());
  final StudentLoginUpdateController studentLoginUpdateControllers =Get.put( StudentLoginUpdateController());
  final StudentProfileController studentProfileController = Get.put(StudentProfileController());

  var box = Hive.box("schoolData");
  @override
  void initState() {
    studentname = box.get("studentname");
    studentclass = box.get("studentclass");
    studentsection = box.get("studentsection");
    studenttotalfees = box.get("studenttotalfees");
    studentduefees = box.get("studentduefees");
    studentpresent = box.get("studentpresent");
    total_deposite_amount = box.get("total_deposite_amount");

    schoolname = box.get("schoolname");
    session = box.get("session");
    id = box.get("student_id");
    company_key = box.get("company_key");

    print("CKECKCKCKCKCKKKCKCK");
    print(studentduefees);
    super.initState();
    feeController.loadingfees.value=false;
    feeController.Feesapi(studentProfileController.studentProfileModel.value?.response.studentId, company_key);
    studentpro=box.get("studentprofileimage");
    username = box.get("username");
    password =box.get("password");
    // studentLoginUpdateControllers.apicallpost(username,password);
  }

  final colorList = <Color>[
    const Color.fromRGBO(245, 10, 45, 1.0),
    const Color.fromRGBO(37, 171, 29, 1.0)

  ];

  int key = 0;
  final index=0;
  int _index=0;
  int s=0;
  String dropdownvalue = 'Select your Address';
  String area = 'Select your Area';

  int _currentIndex = 0;
  late PageController _pageController;
  // List of items in our dropdown menu
  var items = [
    'Mohan Sharma',
    'Mohan garase',
    'Shani patel',
    'Mohan kapoor',
    'Mohan panday',
  ];
  var items1 = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
  ];
  @override
  Widget build(BuildContext context) {
     _onRefresh() async {
        const AlwaysScrollableScrollPhysics();
        setState(() {
          feeController.loadingfees.value=false;
          feeController.Feesapi(studentProfileController.studentProfileModel.value?.response.studentId, company_key).then((value){
 if(value=="repage"){
  setState(() {
    print(value);
  });
 }
          });
         studentProfileController.studentProfileApi(studentProfileController.studentProfileModel.value?.response.studentId);
        });
        await Future.value({

          const Duration(seconds:1 ),

        });
         _refreshController.refreshCompleted();
      };
    return  SmartRefresher(
        controller: _refreshController,
        
        onRefresh: _onRefresh,
      child: Scaffold(

        appBar: AppBar(
         backgroundColor: Theme.of(context).primaryColor,
          title: Text('Fees',style: MyGoogeFont.mydmSans),
        ),
        body:Obx(()=>
         feeController.loadingfees.value?
 FeesWidget(total_balance_amount: '${feeController.studentFeesModel.value?.response.totalBalanceAmount}',
total_amount: '${feeController.studentFeesModel.value?.response.totalAmount}',
name: studentProfileController.studentProfileModel.value?.response.name,
profileimage: studentProfileController.studentProfileModel.value?.response.profileimage,
responseClass: studentProfileController.studentProfileModel.value?.response.responseClass,
section: studentProfileController.studentProfileModel.value?.response.section,
total_discount_amount: '${feeController.studentFeesModel.value?.response.totalDiscountAmount}',
total_deposite_amount: '${feeController.studentFeesModel.value?.response.totalDepositeAmount}',
total_fine_amount: '${feeController.studentFeesModel.value?.response.totalFineAmount}'
)
          :const Center(child: CircularProgressIndicator()),
        ),

      ),
  
    );

  }
}
