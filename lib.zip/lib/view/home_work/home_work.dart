import 'dart:async';

import 'package:ecom_desgin/Widgets/TextFieldWidget.dart';
import 'package:ecom_desgin/Widgets/button_widget.dart';
import 'package:ecom_desgin/constant/Colors.dart';
import 'package:ecom_desgin/constant/date_format.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/controller/home_word_controller.dart';
import 'package:ecom_desgin/controller/homeworkcreate_controller.dart';
import 'package:ecom_desgin/controller/student_profile-Controller.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'dart:io';
import 'package:google_fonts/google_fonts.dart';
import 'package:dio/dio.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart';
import 'package:downloads_path_provider_28/downloads_path_provider_28.dart';

class HomeWork extends StatefulWidget {
  const HomeWork({super.key});

  @override
  State<HomeWork> createState() => _HomeWorkState();
}

class _HomeWorkState extends State<HomeWork> {
  String name = "";
  bool changeButton = false;
  final _formkey = GlobalKey<FormState>();
  final HomeWorkController _homeWorkController = Get.put(HomeWorkController());
  final StudentProfileController studentProfileController =
      Get.put(StudentProfileController());

  var contenttileController = TextEditingController();
  var noteController = TextEditingController();
  bool noteValidate = false;
  final HomeWorkCreateController homeworkcreate =
      Get.put(HomeWorkCreateController());
  var show;
  var showall;
  var title;
  var company_key;
  var content_title;
  bool fileselected = false;
  var homework_date;
  var submit_date;
  var note;
  var homework_id;
  var userfile;
  late var context;
  var student_id;
  var file;
  var fileData;
  // FormData formData = new FormData.from({
  //   "name": "wendux",
  //   "file1": new UploadFileInfo(new File("./upload.jpg"), "upload1.jpg")
  // });
  // response = await dio.post("/info", data: formData)
  String _selectdrop = "select";
  List<String> dropdata = ["hindi", "math"];
  bool uploadDone = false;

  double progress = 0;

  bool didDownloadPDF = false;
  bool isdownloadin = true;
  int index = 0;
  var box = Hive.box("schoolData");
  late var id =
      studentProfileController.studentProfileModel.value?.response.studentId;

  String progressString = 'Now';
  late Directory _downloadsDirectory;

  var _formKey = GlobalKey<FormState>();
  var isLoading = false;

  void _submit() {
    final isValid = _formKey.currentState?.validate();
    if (!isValid!) {
      return;
    }
    _formKey.currentState?.save();
  }

  @override
  void initState() {
    company_key = box.get("company_key");
    student_id =
        studentProfileController.studentProfileModel.value?.response.studentId;
    _homeWorkController.homeworkapi(
        studentProfileController.studentProfileModel.value?.response.studentId);
    super.initState();
    initDownloadsDirectoryState();
  }

  Future<void> initDownloadsDirectoryState() async {
    Directory? downloadsDirectory;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      downloadsDirectory = await DownloadsPathProvider.downloadsDirectory;
    } on PlatformException {
      print('Could not get the downloads directory');
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    _downloadsDirectory = downloadsDirectory!;
  }

  Future download(Dio dio, String Path, String savePath) async {
    try {
      var response = await dio.get(
        Path,
        onReceiveProgress: updateProgress,
        options: Options(
            responseType: ResponseType.bytes,
            followRedirects: false,
            validateStatus: (status) {
              return status! < 500;
            }),
      );
      var file = File(savePath).openSync(mode: FileMode.write);
      file.writeFromSync(response.data);
      await file.close();
    } catch (e) {
      print(e);
    }
  }

  void updateProgress(done, total) {
    progress = done / total;
    setState(() {
      if (progress >= 1) {
        progressString = '✅ finished downloading';
        didDownloadPDF = true;
      } else {
        progressString = (progress * 100).toStringAsFixed(0) + '% done.';
      }
    });
  }

//pdf dwonlad work it
  pdfDownload(pdfurl, value) async {
    print('dkkdkdkd');
    print(pdfurl);
    setState(() {
      isdownloadin = false;
      index = value;
    });
    Map<Permission, PermissionStatus> statuses = await [
      Permission.storage,
      //add more permission to request here.
    ].request();
    String i = "";
    i = DateTime.now().toString();
    if (pdfurl.toString().isNotEmpty) {
      if (statuses[Permission.storage]!.isGranted) {
        var dir = await DownloadsPathProvider.downloadsDirectory;

        Future<Directory?> downloadsDirectory =
            DownloadsPathProvider.downloadsDirectory;
        // Directory dir = Directory('/storage/emulated/0/Download');
        if (dir != null) {
          String savename = "file.pdf";
          String savePath = "${dir.path}/$savename";
          print(savePath);
          //output:  /storage/emulated/0/Download/banner.png

          try {
            await Dio().download(pdfurl.toString(), savePath,
                onReceiveProgress: (received, total) {
              if (total != -1) {
                print("${(received / total * 100).toStringAsFixed(0)}%");
                progressString =
                    "${(received / total * 100).toStringAsFixed(0)}%";
                setState(() {});
                //you can build progressbar feature too
              }
            });
            isdownloadin = true;
            Get.snackbar(
                "Download Successfull", "File is saved to download folder");
          } on DioError catch (e) {
            print(e.message);
          }
        }
      } else {
        print("No permission to read and write.");
      }
    } else {
      Get.snackbar("File Not Available", "");
    }
  }

  void filepicker() {
    setState(() {});
  }

  void showCustomDialog(BuildContext context) {
    noteController.clear();
    contenttileController.clear();
    fileData = "";

    showGeneralDialog(
      context: context,
      barrierLabel: "Barrier",
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: const Duration(milliseconds: 700),
      pageBuilder: (_, __, ___) {
        return Material(
          color: Colors.transparent,
          child: StatefulBuilder(builder: (context, setState) {
            return Center(
              child: InkWell(
                onTap: () {
                  setState(() {
                    print("dfd");
                  });
                },
                child: Container(
                  height: 0.65.sh,
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                  ),
                  child: SizedBox.expand(
                      child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        height: 0.02.sh,
                        color: Colors.blue,
                      ),
                      const Text(
                        "Home Work Upload",
                        style: TextStyle(fontSize: 20),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RichText(
                              text: const TextSpan(
                                text: 'Home Work List',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                                children: <TextSpan>[
                                  TextSpan(
                                      text: '*',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.red)),
                                ],
                              ),
                            ),
                            // DropdownButton<String>(
                            //   isExpanded: true,
                            //   hint: Text(_selectdrop,
                            //       style: const TextStyle(color: Colors.blueAccent)),
                            //   items: dropdata.map((String value) {
                            //     return DropdownMenuItem<String>(
                            //       value: value,
                            //       child: Text(
                            //         value,
                            //         style:
                            //             const TextStyle(color: Colors.blueAccent),
                            //       ),
                            //     );
                            //   }).toList(),
                            //   onChanged: (String? newValue) {
                            //     print(newValue);
                            //     setState(() {
                            //       _selectdrop = newValue!;
                            //     });
                            //   },
                            // ),
                          ],
                        ),
                      ),
                      Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomTextField(
                                hint: 'Content Title',
                                controller: contenttileController,
                                inputType: TextInputType.text,
                                obscureText: false,
                                onChange: (value) {},
                              ),
                              CustomTextField(
                                hint: 'Description',
                                controller: noteController,
                                inputType: TextInputType.text,
                                obscureText: false,
                                onChange: (value) {},
                              ),
                            ],
                          )),

                      Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: const TextSpan(
                                  text: 'File',
                                  style: TextStyle(
                                    color: Colors.black,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                        text: '*',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.red)),
                                  ],
                                ),
                              ),
                              Container(
                                height: 0.08.sh,
                                width: 0.95.sw,
                                color: Colors.white,
                                child: Row(
                                  children: [
                                    FloatingActionButton(
                                        child: Icon(Icons.upload_sharp),
                                        backgroundColor: Colors.white,
                                        onPressed: () async {
                                          FilePickerResult? result =
                                              await FilePicker.platform
                                                  .pickFiles();

                                          if (result != null) {
                                            PlatformFile file =
                                                result.files.first;

                                            print(file.name);
                                            print(file.bytes);
                                            print(file.size);
                                            print(file.extension);
                                            print(file.path);
                                            userfile = file.path;
                                            fileData = file.name;

                                            setState(() {
                                              if (fileData
                                                      .toString()
                                                      .isNotEmpty &&
                                                  contenttileController.text
                                                      .toString()
                                                      .isNotEmpty &&
                                                  noteController.text
                                                      .toString()
                                                      .isNotEmpty) {
                                                print("fdfhgh");
                                              }
                                              if (content_title
                                                  .toString()
                                                  .isNotEmpty) {
                                                if (note
                                                    .toString()
                                                    .isNotEmpty) {
                                                  if (fileData.toString() !=
                                                      "null") {
                                                    if (homework_id
                                                        .toString()
                                                        .isNotEmpty) {
                                                      fileselected = true;
                                                    }
                                                  } else {
                                                    Get.snackbar(
                                                      "Please Select File",
                                                      "",
                                                      duration: 5
                                                          .seconds, // it could be any reasonable time, but I set it lo-o-ong
                                                      snackPosition:
                                                          SnackPosition.BOTTOM,
                                                      showProgressIndicator:
                                                          true,

                                                      isDismissible: true,
                                                      backgroundColor:
                                                          Colors.lightGreen,
                                                      colorText: Colors.white,
                                                      mainButton: TextButton(
                                                          onPressed: Get.back,
                                                          child: const Text(
                                                              "Close")),
                                                    );
                                                  }
                                                } else {
                                                  Get.snackbar(
                                                    "Please Select Description",
                                                    "",
                                                    duration: 5
                                                        .seconds, // it could be any reasonable time, but I set it lo-o-ong
                                                    snackPosition:
                                                        SnackPosition.BOTTOM,
                                                    showProgressIndicator: true,

                                                    isDismissible: true,
                                                    backgroundColor:
                                                        Colors.lightGreen,
                                                    colorText: Colors.white,
                                                    mainButton: TextButton(
                                                        onPressed: Get.back,
                                                        child: const Text(
                                                            "Close")),
                                                  );
                                                }

                                                // _submit();
                                              } else {
                                                Get.snackbar(
                                                  "Please Select Content Title",
                                                  "",
                                                  duration: 5
                                                      .seconds, // it could be any reasonable time, but I set it lo-o-ong
                                                  snackPosition:
                                                      SnackPosition.BOTTOM,
                                                  showProgressIndicator: true,

                                                  isDismissible: true,
                                                  backgroundColor:
                                                      Colors.lightGreen,
                                                  colorText: Colors.white,
                                                  mainButton: TextButton(
                                                      onPressed: Get.back,
                                                      child:
                                                          const Text("Close")),
                                                );
                                              }
                                              ;
                                            });
                                            filepicker();
                                          } else {
                                            fileselected = false;

                                            throw "Cancelled File Picker";
                                            print('No file selected');
                                          }
                                        }),
                                    SizedBox(
                                      width: 0.60.sw,
                                      child: Text(
                                        fileData ?? "",
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ),


                              Padding(
                                padding: const EdgeInsets.all(15),
                                child: Center(
                                    child: fileselected
                                        ? ButtonWidget(
                                            bh: 50,
                                            bw: 150,
                                            borderredius: 10,
                                            buttonColor:
                                                AgentColor.buttonColors,
                                            child: const Text(
                                              "Upload",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 18),
                                            ),
                                            onTap: () {
                                              print("uploading  data");
                                              print(content_title);
                                              print(note);
                                              print(fileData);
                                              print(homework_id);
                                              note = noteController.text;
                                              content_title =
                                                  contenttileController.text;

                                              if (fileselected == true) {
                                                homeworkcreate
                                                    .HomeWorkCreateapi(
                                                        company_key,
                                                        student_id,
                                                        content_title,
                                                        note,
                                                        userfile,
                                                        homework_id);

                                                noteController.clear();
                                                contenttileController.clear();
                                                fileData = "";
                                              }
                                              Navigator.pop(context);
                                            },
                                          )
                                        : const ButtonWidget(
                                            bh: 50,
                                            bw: 150,
                                            borderredius: 20,
                                            buttonColor: Colors.grey,
                                            child: Text(
                                              "Upload",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 18),
                                            ),
                                          )),
                              ),
                            ],
                          ))
                    ],
                  )),
                ),
              ),
            );
          }),
        );
      },
      transitionBuilder: (_, anim, __, child) {
        Tween<Offset> tween;
        if (anim.status == AnimationStatus.reverse) {
          tween = Tween(begin: const Offset(-1, 0), end: Offset.zero);
        } else {
          tween = Tween(begin: const Offset(1, 0), end: Offset.zero);
        }

        return SlideTransition(
          position: tween.animate(anim),
          child: FadeTransition(
            opacity: anim,
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text('Home Work', style: MyGoogeFont.mydmSans),
        ),
        body: Obx(() => _homeWorkController.isloading.value
            ? RefreshIndicator(
                onRefresh: () async {
                  print("4444444444444444444444444444333");
                  setState(() {
                    _homeWorkController.isloading.value = false;
                    _homeWorkController.homeworkapi(id).then((value){
                      if(value=="Repage"){
                        setState(() {
                          print(value);
                        });
                      }
                    });
                  });
                },
                child:ListView.builder(
                    itemCount:
                        _homeWorkController.studentHomeWorkModel.value?.response.length,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    itemBuilder: (context, int i) => Padding(
                          padding: const EdgeInsets.all(2.5),
                          child: InkWell(
                            onTap: () {
                              setState(() {});
                            },
                            child: Card(
                              elevation: 10,
                              child: Container(
                                width: 0.95.sw,
                                height: 0.20.sh,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Color.fromARGB(255, 255, 255, 255),
                                ),
                                child: Row(
                                  /////////////////////////////////////////////////////////////////////////////////                          // ignore: prefer_const_literals_to_create_immutables
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                bottomLeft: Radius.circular(10))
                                            .r,
                                        color: Colors.red,
                                      ),
                                      width: 0.001.sw,
                                      height: 0.20.sh,
                                    ),
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: 0.94.sw,
                                          height: 0.002.sh,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(20).r,
                                            color: Colors.red,
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                                  left: 10, top: 5)
                                              .r,
                                          child: Row(
                                            // ignore: prefer_const_literals_to_create_immutables
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              Text(
                                                _homeWorkController.studentHomeWorkModel.value?.response[i].status
                                                        .toString()
                                                        .capitalizeFirst ??
                                                    "",
                                                style: const TextStyle(
                                                    color: Colors.red,
                                                    fontSize: 18),
                                              ),
                                              SizedBox(
                                                width: 0.33.sw,
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    right: 18),
                                                child: InkWell(
                                                  onTap: () async {
                                                    _homeWorkController
                                                        .isdownloadinmethod();

                                                    pdfDownload(
                                                        _homeWorkController.studentHomeWorkModel.value?.response[i].document ??
                                                            "",
                                                        i);
                                                    setState(() {});
                                                  },
                                                  child: isdownloadin
                                                      ? Row(
                                                          children: [
                                                            Text(
                                                              "Download",
                                                              style: GoogleFonts
                                                                  .dmSans(
                                                                fontStyle:
                                                                    FontStyle
                                                                        .normal,
                                                                fontSize: 15.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .black,
                                                              ),
                                                            ),
                                                            Icon(Icons.download)
                                                          ],
                                                        )
                                                      : index == i
                                                          ? Row(
                                                              children: [
                                                                InkWell(
                                                                  onTap:
                                                                      () async {

                                                                  },
                                                                  child:
                                                                      SizedBox(
                                                                    width:
                                                                        0.32.sw,
                                                                    child: Text(
                                                                      "Download:$progressString",
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      style: GoogleFonts
                                                                          .dmSans(
                                                                        fontStyle:
                                                                            FontStyle.normal,
                                                                        fontSize:
                                                                            15.sp,
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            )
                                                          : Row(
                                                              children: [
                                                                Text(
                                                                  "Download",
                                                                  style:
                                                                      GoogleFonts
                                                                          .dmSans(
                                                                    fontStyle:
                                                                        FontStyle
                                                                            .normal,
                                                                    fontSize:
                                                                        15.sp,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    color: Colors
                                                                        .black,
                                                                  ),
                                                                ),
                                                                Icon(Icons
                                                                    .download)
                                                              ],
                                                            ),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 10.0)
                                                  .r,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                width: 0.25.sw,
                                                child: Text(
                                                  _homeWorkController.studentHomeWorkModel.value?.response[i].subjectName
                                                          .toString()
                                                          .toUpperCase() ??
                                                      "",
                                                  style: GoogleFonts.dmSans(
                                                    fontStyle: FontStyle.normal,
                                                    fontSize: 18.sp,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black,
                                                  ),
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                              IconButton(
                                                  onPressed: () {
                                                    showDialog(
                                                      context: context,
                                                      builder: (ctx) =>
                                                          AlertDialog(
                                                        title: Text(
                                                          "Description",
                                                          style: GoogleFonts
                                                              .dmSans(
                                                            fontStyle: FontStyle
                                                                .normal,
                                                            fontSize: 20.sp,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color: Colors.black,
                                                          ),
                                                        ),
                                                        backgroundColor:
                                                            Colors.white,
                                                        content: Text(
                                                            Bidi.stripHtmlIfNeeded(
                                                                _homeWorkController.studentHomeWorkModel.value?.response[i].description??""),
                                                            style: GoogleFonts
                                                                .dmSans(
                                                              fontStyle:
                                                                  FontStyle
                                                                      .normal,
                                                              fontSize: 15.sp,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.black,
                                                            )),


                                                        actions: <Widget>[
                                                          ElevatedButton(
                                                              onPressed: () {
                                                                Navigator.of(
                                                                        ctx)
                                                                    .pop();
                                                              },
                                                              style:
                                                                  ButtonStyle(
                                                                backgroundColor:
                                                                    MaterialStateProperty
                                                                        .all(Colors
                                                                            .blue),
                                                              ),
                                                              child: Text(
                                                                "okay",
                                                                style:
                                                                    GoogleFonts
                                                                        .dmSans(
                                                                  fontStyle:
                                                                      FontStyle
                                                                          .normal,
                                                                  fontSize:
                                                                      15.sp,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              )),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                  icon: const Icon(Icons
                                                      .visibility_outlined)),
                                              Padding(
                                                padding:
                                                    EdgeInsets.only(left: 54.0)
                                                        .r,
                                                child: InkWell(
                                                  onTap: () {
                                                    if ( _homeWorkController.studentHomeWorkModel.value?.response[i].status
                                                            .toString()
                                                            .toLowerCase() ==
                                                        "pending") {
                                                      if (_homeWorkController
                                                                  .homeWorkControllerList[
                                                              0] !=
                                                          null) {
                                                        homework_id = _homeWorkController .isloading.value ?  _homeWorkController.studentHomeWorkModel.value?.response[i].id
                                                                : "";
                                                      }
                                                      fileselected = false;
                                                      showCustomDialog(context);
                                                    }
                                                    ;
                                                  },
                                                  child:  _homeWorkController.studentHomeWorkModel.value?.response[i].status
                                                              .toString()
                                                              .toLowerCase() ==
                                                          "pending"
                                                      ? Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Text(
                                                              "Upload",
                                                              style: GoogleFonts
                                                                  .dmSans(
                                                                fontStyle:
                                                                    FontStyle
                                                                        .normal,
                                                                fontSize: 15.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .black,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 0.05.sw,
                                                            ),
                                                            const Icon(
                                                                Icons.upload),
                                                          ],
                                                        )
                                                      : Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Text(
                                                              "Upload",
                                                              style: GoogleFonts
                                                                  .dmSans(
                                                                fontStyle:
                                                                    FontStyle
                                                                        .normal,
                                                                fontSize: 15.sp,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color:
                                                                    Colors.grey,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 0.05.sw,
                                                            ),
                                                            const Icon(
                                                              Icons.upload,
                                                              color:
                                                                  Colors.grey,
                                                            ),
                                                          ],
                                                        ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        // SizedBox(
                                        //  height: 0.05.sw,
                                        // ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 10),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              Text(
                                                "Evulationdate:-",
                                                style: GoogleFonts.dmSans(
                                                  fontStyle: FontStyle.normal,
                                                  fontSize: 11.sp,
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black,
                                                ),
                                              ),
                                              SizedBox(
                                                width: 0.25.sw,
                                                child:
                                                   Text(
                                                     _homeWorkController.studentHomeWorkModel.value?.response[i].evaluationDate!="null"? MyDateFormat.dateformatmethod1(
                                                        _homeWorkController.studentHomeWorkModel.value?.response[i].evaluationDate):"",
                                                        style: GoogleFonts.dmSans(
                                                          fontStyle:
                                                              FontStyle.normal,
                                                          fontSize: 10.sp,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: Colors.black,
                                                        ),

                                                )),

                                              SizedBox(
                                                width: 0.02.sw,
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  // ignore: prefer_const_constructors
                                                  Text(
                                                    "submission Date:-",
                                                    style: GoogleFonts.dmSans(
                                                      fontStyle:
                                                          FontStyle.normal,
                                                      fontSize: 10.sp,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color: Colors.black,
                                                    ),
                                                  ),

                                                 Text(
                                                   _homeWorkController.studentHomeWorkModel.value?.response[i].submitDate!="null"?MyDateFormat.dateformatmethod1(
                                                            _homeWorkController.studentHomeWorkModel.value?.response[i].submitDate):"",
                                                        style: GoogleFonts.dmSans(
                                                          fontStyle:
                                                              FontStyle.normal,
                                                          fontSize: 10.sp,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: Colors.black,
                                                        ),

                                                  ),

                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                                  top: 3, left: 8.0)
                                              .r,
                                          child: Row(
                                            children: [
                                              Image.asset(
                                                "assets/images/teacher.png",
                                                width: 20,
                                                height: 20,
                                              ),
                                           Padding(
                                                  padding:
                                                      EdgeInsets.only(left: 3)
                                                          .r,
                                                  child: Text(
                                                    _homeWorkController.studentHomeWorkModel.value?.response[i].staffName
                                                                .toString()
                                                                .capitalize ??
                                                            "",style: GoogleFonts.dmSans(
                                                      fontStyle:
                                                          FontStyle.normal,
                                                      fontSize: 13.sp,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color: Colors.black,
                                                    ),
                                                  ),
                                                ),

                                            ],
                                          ),
                                        ),
                                      ],
                                    ),


                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),)
              )
            : const Center(
                child: CircularProgressIndicator(
                  color: Colors.blue,
                ),
              )));
  }
}
