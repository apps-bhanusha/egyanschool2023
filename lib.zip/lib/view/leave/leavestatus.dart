import 'dart:async';

import 'package:ecom_desgin/Widgets/Leave_widget.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:ecom_desgin/controller/addstudentLeaveRecord_controller.dart';
import 'package:ecom_desgin/controller/studentLeaveRecord_controller.dart';
import 'package:ecom_desgin/controller/student_profile-Controller.dart';
import 'package:ecom_desgin/view/leave/user_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';


class LeaveStatus extends StatefulWidget {
  const LeaveStatus({Key? key}) : super(key: key);

  @override
  _LeaveStatusState createState() => _LeaveStatusState();
}

class _LeaveStatusState extends State<LeaveStatus> {
  var company_key;
  var userfile;
  var id;
  // ignore: non_constant_identifier_names
  StudentLeaveRecordController StudentLeaveRecord=Get.put(StudentLeaveRecordController());
  AddStudentLeaveRecordController AddStudentLeaveRecord =
  Get.put(AddStudentLeaveRecordController());
  final StudentProfileController studentProfileController = Get.put(StudentProfileController());

  int currentTab = 0;
  DateTime today = DateTime.now();

  DateFormat currentDate=DateFormat.yMd();
RefreshController _refreshController =
  RefreshController(initialRefresh: false);

  get dateStr => "${today.day}-${today.month}-${today.year}";
  var box = Hive.box("schoolData");
@override
  void initState() {
  String dateStr = "${today.day}-${today.month}-${today.year}";
  print(dateStr);
    super.initState();

  id = box.get("student_id");
  company_key = box.get("company_key");
  StudentLeaveRecord.StudentLeaveRecordapi(company_key,studentProfileController.studentProfileModel.value?.response.studentId);
  }

  @override
  Widget build(BuildContext context) {
    void addUserData() {
    }

    void showUserDialog() {
      showDialog(
        context: context,
        builder: (_) =>
         AlertDialog(
           content: AddUserDialog(
             
           ),
           shape: RoundedRectangleBorder(
             borderRadius: BorderRadius.circular(10),
           ),
         ),

      );
    }
 _onRefresh() async {
   await Future.value({

          const Duration(seconds:3 ),

        });
         setState(() {
           StudentLeaveRecord.loadingStudentLeaveRecord.value=false;
          StudentLeaveRecord.StudentLeaveRecordapi(company_key,studentProfileController.studentProfileModel.value?.response.studentId).then((value) {
       if(value=="refreshpage"){
        setState(() {
          print("update page");
        });
       }
          });
        });
    
       
         _refreshController.refreshCompleted();
      };
    return  SmartRefresher(
        controller: _refreshController,
        
        onRefresh: _onRefresh,
      child: Scaffold(
        appBar: AppBar(
         backgroundColor: Theme.of(context).primaryColor,
          title: Text('Leave Status',style: MyGoogeFont.mydmSans),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: showUserDialog,
          child: Icon(Icons.add),  
        ),//StudentLeaveRecord.loadingStudentLeaveRecord.value?
        body: Obx(
          () => StudentLeaveRecord.isloading.value==false?StudentLeaveRecord.loadingStudentLeaveRecord.value?ListView.builder(
            itemBuilder: (ctx, index) {
           return LeaveWidget(applyDate:StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].applyDate!="null"? '${StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].applyDate}':"",
leave_from: StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].fromDate!="null"?'${StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].fromDate}':"" ,
leave_to: StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].leaveStatus!="null"?'${StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].toDate}':"",
status: StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].leaveStatus!="null"? '${StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].leaveStatus}':"",
applied_by: StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].approvedByStaffName!="null"? '${StudentLeaveRecord.studentLeaveStatusModel.value?.response[index].approvedByStaffName}':"",
);
           },
            itemCount: StudentLeaveRecord.isloading.value==false? StudentLeaveRecord.StudentLeaveRecordControllerList[0]["response"].length:0,
          ):const Center(child: CircularProgressIndicator(color: Colors.blue),):const Center(child: Text("Record Not Found"),)
      ),
        floatingActionButtonLocation: FloatingActionButtonLocation.miniCenterFloat,
      ),
    
    );
  }
}
