import 'dart:convert';
import 'package:ecom_desgin/constant/api_url.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'package:http/http.dart' as http;

class AttendanceController extends GetxController {
  List <dynamic> AttendanceControllerList = [].obs;


  RxBool loadingattendance =false.obs;
  Future<List<AttendanceController>?> Attendanceapi(year,month,id, company_key) async {

    var body = json.encode({
      "company_key":company_key,
      "student_id": id,
      "month":month,
      "year":year,
    });
    print("46555555555555555555555554444444444444444444fgggggggggg55544444444");
    print(body);
    final urlapi = Uri.parse(ApiUrl.baseUrl+ApiUrl.attendanceUrl);
    var response = await http.post(urlapi, body: body);
    if (response.statusCode == 200) {
      var  sdata = jsonDecode(response.body);


      print("555555555555555555555jjjjjjjj444444444444444444444444ggggggggggjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj");
      print(AttendanceControllerList);
      print(AttendanceControllerList[0]["response"][0]["date"]);
      print(AttendanceControllerList[0]["response"][0]["title"]);

      if (sdata["status"] == true && AttendanceControllerList[0]["response"][i]["date"]) {
        AttendanceControllerList=[];
        AttendanceControllerList.add(sdata);
        loadingalldata();
        print("massage");
      }
      else  {
        print("invalid cccid");
      } }
    else {

      print("School ID Invailid");
    }
  }

  void loadingalldata() {

    var box = Hive.box("schoolData");

for(var i=0; i<AttendanceControllerList[0]["response"][i]["date"].length;i++)
    box.put("date",AttendanceControllerList[0]["response"][i]["date"]);
    // box.put("title",AttendanceControllerList[0]["response"][0]["title"]);
    // box.put("AttendanceControllerList",AttendanceControllerList);
  }}
