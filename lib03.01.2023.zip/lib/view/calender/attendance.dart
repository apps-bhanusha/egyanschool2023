import 'dart:math';
import 'package:ecom_desgin/controller/attendance_controller.dart';
import 'package:get/get.dart';

import 'package:intl/intl.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/cupertino.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart'
    show CalendarCarousel;
import 'package:flutter_calendar_carousel/classes/event.dart';
import 'package:flutter_calendar_carousel/classes/event_list.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:date_format/date_format.dart';
import 'package:jiffy/jiffy.dart';
class Attendance extends StatefulWidget {

  @override
  _AttendanceState createState() => new _AttendanceState();
}
var dateapi;
var test;
List<DateTime> presentDates = [

  // DateTime(2022, 11, 2),
  // DateTime(2022, 11, 3),
  // DateTime(2022, 11, 4),
  // DateTime(2022, 11, 5),
  // DateTime(2022, 11, 6),
  // DateTime(2022, 11, 9),
  // DateTime(2022, 11, 10),
  // DateTime(2022, 11, 11),
  // DateTime(2022, 11, 15),
  // DateTime(2022, 11, 22),
  // DateTime(2022, 11, 23),
];
List<DateTime> absentDates = [
  DateTime(2022, 1,4),
  DateTime(2022, 11, 7),
  DateTime(2022, 11, 8),
  DateTime(2022, 11, 12),
  DateTime(2022, 11, 13),
  DateTime(2022, 11, 14),
  DateTime(2022, 11, 16),
  DateTime(2022, 11, 17),
  DateTime(2022, 11, 18),
  DateTime(2022, 11, 19),
  DateTime(2022, 12, 20),
];

class _AttendanceState extends State<Attendance> {


  final AttendanceController studentattendance = Get.put(AttendanceController());
var dateapi;
late var date;
  late final outputFormat;
  late String title;
  var allsplit;
  var id;
  var company_key;
  final index=0;
 late var year;
 late var month;
 late var days;



  late List<_ChartData> data;
  late TooltipBehavior _tooltip;
  DateTime _currentDate = DateTime.now();
  DateTime _currentDate2 = DateTime.now();
  String _currentMonth = DateFormat.yMMM().format(DateTime.now());
  DateTime _targetDateTime = DateTime.now();
 // late DateTime dateTime = dateFormat.parse(date);
  // DateTime _currentDate2 = DateTime.now();
  var dt = DateTime.now();
  var box = Hive.box("schoolData");

  // static get dateFormat => 'yyyy,MM,dd';

  @override
  void initState() {
    _tooltip = TooltipBehavior(enable: true);

    id = box.get("student_id");
    company_key = box.get("company_key");
    studentattendance.Attendanceapi("2022","12", id ,company_key);
    date=box.get("date");

    print("555555555555555555555555555555kkkkkkkkkkkkkkkkkkk");
print(date);
    print(absentDates);
    print(DateTime(2022, 1,4),);
   //  allsplit=date.toString().split("-");
   //  print(allsplit);
   //  dateapi=allsplit.join(", ");
   // print(dateapi);
    year = Jiffy(date).year;
     month=Jiffy(date).month;
     days=Jiffy(date).date;
    // var a = Jiffy(DateTime(int.parse(date))).yMMMMd;
    print(year);
    print(month);
    print(days);
   // print(dateapi.days);
   // print(dateapi.year);
   // print(dateapi.month);

    // var formattedDate = DateTime.parse(dateapi);
    // print(formattedDate);
    // int? test = int.parse(dateapi);
    //
    // print("$test");

  // outputFormat = DateFormat('yy,M,d').format(date);
  //   print(formatDate(DateTime((int.parse(date.toString()))), [yyyy, ',', mm, ',', dd]));

// print(dateTime);
    // DateTime outputFormat = DateFormat('y,MM,dd').parse(date);
    // print(date);
    // print(title);
// print(outputFormat);

    // presentDates.add(DateTime(year,month,days));
    presentDates.add(DateTime(year,month,days));

    print(presentDates);



    // title=box.get("title");
    data = [
      _ChartData('Jan', 8, Color.fromRGBO(245, 67, 44, 1.0)),
      _ChartData('Feb', 25, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Mar', 31, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Apr', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('May', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Jun', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Jul', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Aug', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Spt', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Oct', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Nov', 0, Color.fromRGBO(37, 171, 29, 1.0)),
      _ChartData('Dec', 0, Color.fromRGBO(37, 171, 29, 1.0)),
    ];


    super.initState();
  }
  static Widget _presentIcon(String day) => CircleAvatar(
    backgroundColor: Colors.green,
    child: Text(
      day,
      style: TextStyle(
        color: Colors.white,
      ),
    ),
  );
  static Widget _absentIcon(String day) => CircleAvatar(
    backgroundColor: Colors.red,
    child: Text(
      day,
      style: TextStyle(
        color: Colors.white,
      ),
    ),
  );

  EventList<Event> _markedDateMap = new EventList<Event>(
    events: {},
  );

  late CalendarCarousel _calendarCarouselNoHeader;

  // var len = min(absentDates.length, presentDates.length);
  // late double cHeight;

  @override
  Widget build(BuildContext context) {
    // cHeight = MediaQuery.of(context).size.height;
    for (int i = 0; i <presentDates.length; i++) {
      _markedDateMap.add(
        presentDates[i],

         Event(
          date: presentDates[i],
          title: 'Event 5',
          icon: _presentIcon(
            presentDates[i].day.toString(),
          ),
        ),
      );
    }

    for (int i = 0; i < absentDates.length; i++) {
      _markedDateMap.add(
        absentDates[i],
        new Event(
          date: absentDates[i],
          title: 'Event 5',
          icon: _absentIcon(
            absentDates[i].day.toString(),
          ),
        ),
      );
    }

    _calendarCarouselNoHeader = CalendarCarousel<Event>(
      height: 0.56.sh,
      // height: cHeight * 0.54,
      weekendTextStyle: TextStyle(
        color: Colors.red,
      ),
      todayButtonColor: Colors.blue,

      markedDatesMap: _markedDateMap,
      daysHaveCircularBorder: false,
      markedDateShowIcon: true,
      showOnlyCurrentMonthDate: true,
      markedDateIconMaxShown: 1,
      markedDateMoreShowTotal:

      null,
      thisMonthDayBorderColor: Color.fromARGB(255, 206, 204, 204),// null for not showing hidden events indicator
      markedDateIconBuilder: (event) {
        return event.icon;
      },
    );

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        title: Row(
          children: [
            Container(
              child: Text(
                'EGYAN Demo school',
                style: GoogleFonts.dmSans(
                  fontStyle: FontStyle.normal,
                  fontSize:15.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.redAccent,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 26).r,
              child: Column(
                children: [
                  Container(
                    child: Text(
                      'Session',
                      style: GoogleFonts.dmSans(
                        fontStyle: FontStyle.normal,
                        fontSize:12.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  Container(
                    child: Text(
                      '2020-21',
                      style: GoogleFonts.dmSans(
                        fontStyle: FontStyle.normal,
                        fontSize:12.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<int>(
            itemBuilder: (context) {
              return <PopupMenuEntry<int>>[
                const PopupMenuItem(child: Text('0'), value: 0),
                const PopupMenuItem(child: Text('1'), value: 1),
              ];
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 150).r,
              child: Text(
                'Student Atendance',
                style: GoogleFonts.dmSans(
                  fontStyle: FontStyle.normal,
                  fontSize:15.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            Container(
              height: 0.25.sh,

              child: SfCartesianChart(
                  plotAreaBorderWidth: 0,
                  primaryXAxis: CategoryAxis(
                    majorGridLines: MajorGridLines(width: 0),


                    axisLine: AxisLine(width: 0),

                  ),

                  primaryYAxis: NumericAxis(minimum: 0, maximum: 31, interval: 5,  numberFormat: NumberFormat.compact(),  majorGridLines: MajorGridLines(width: 0),

                    axisLine: AxisLine(width: 0), ),
                  tooltipBehavior: _tooltip,

                  series: <ChartSeries<_ChartData, String>>[
                    // for(var i=5; i<data.length; i++)
                    ColumnSeries<_ChartData, String>(

                      dataSource: data,
                      xValueMapper: (_ChartData data, _) => data.x,
                      yValueMapper: (_ChartData data, _) => data.y,
                      name: 'Gold',
                      pointColorMapper: (_ChartData data, _) => data.color,
                      // dataLabelSettings: DataLabelSettings(isVisible: true)
                    )

                  ]),
            ),
            Container(
              height: 0.60.sh,
              child: Card(margin: EdgeInsets.only(left: 16.0, right: 16.0,).r,child: Column(
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.lightBlueAccent,
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(10),  topRight: Radius.circular(10)),),

                    height: 0.0035.sh,

                  ) ,
                  Container(margin: EdgeInsets.symmetric(horizontal: 16.0).r,
                  child: _calendarCarouselNoHeader),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                          height: 15,
                          width: 15,
                          color: Colors.red),
                      Container(
                        child: Text("Absent",style: GoogleFonts.dmSans(
                          fontStyle: FontStyle.normal,
                          fontSize:12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.lightBlueAccent,
                        ),),
                      ),
                      Container(
                          height: 15,
                          width: 15,
                          color: Colors.black),

                      Container(
                        child: Text("Present",style: GoogleFonts.dmSans(
                          fontStyle: FontStyle.normal,
                          fontSize:12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.lightBlueAccent,
                        ),),
                      ),
                      Container(
                          height: 15,
                          width: 15,
                          color: Colors.grey),
                      Container(
                        child: Text("Late",style: GoogleFonts.dmSans(
                          fontStyle: FontStyle.normal,
                          fontSize:12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.lightBlueAccent,
                        ),),
                      ),
                      Container(
                          height: 15,
                          width: 15,
                          color: Colors.lightBlue),
                      Container(
                        child: Text("Half Day",style: GoogleFonts.dmSans(
                          fontStyle: FontStyle.normal,
                          fontSize:12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.lightBlueAccent,
                        ),),
                      ),
                      Container(
                          height: 15,
                          width: 15,
                          color: Colors.yellow),
                      Container(
                        child: Text("Holiday",
                          style: GoogleFonts.dmSans(
                            fontStyle: FontStyle.normal,
                            fontSize:12.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.lightBlueAccent,
                          ),),
                      ),
                    ],
                  ),
                ],
              ),

              ),
            ),
            // markerRepresent(Colors.red, "Absent"),
            // markerRepresent(Colors.green, "Present"),
          ],
        ),
      ),
    );
  }

  Widget markerRepresent(Color color, String data) {
    return new ListTile(
      leading: new CircleAvatar(
        backgroundColor: color,
        radius: 0.022.sh,
      ),
      title: new Text(
        data,
      ),
    );
  }
}

class _ChartData {
  _ChartData(this.x, this.y, this.color);

  final Color? color;
  final String x;
  final double y;
}