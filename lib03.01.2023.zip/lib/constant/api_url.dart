class ApiUrl{
 static const String baseUrl="https://e-gyan.co.in/api";
 static const String schollIdUrl="/parentwebservices/getProjectKey";
 static const String studentLoginUrl="/parentwebservices/studentlogin";
 static const String teacherLoginUrl="https://e-gyan.co.in/api";
 static const String homeWorkUrl="/parentwebservices/student_homework";
 static const String getschoolsettingUrl="/parentwebservices/getschoolsetting";
 static const String feeUrl="/parentwebservices/fee";
 static const String attendanceUrl="/parentwebservices/attendence";

}