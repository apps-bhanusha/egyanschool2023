import 'dart:async';
import 'package:ecom_desgin/constant/Colors.dart';
import 'package:ecom_desgin/constant/font.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
class TrackBus extends StatefulWidget {
  const TrackBus({Key? key}) : super(key: key);

  @override
  _TrackBusState createState() => _TrackBusState();
}

class _TrackBusState extends State<TrackBus> {
  Completer<GoogleMapController> _controller = Completer();
  Set<Polyline> _directionPolyline = {};
  Polyline polyLine = Polyline(
    polylineId: const PolylineId('direction'),
    color: Colors.blue,
    points: List.empty(growable: true),
    width: 5,
    startCap: Cap.roundCap,
    endCap: Cap.roundCap,
    jointType: JointType.round,
    geodesic: true,
  );
  List<dynamic> data = [
    {"lat": 22.7172809, "lang": 75.913142, "id": 0},
    {"lat": 22.7170643, "lang": 75.912913, "id": 1},
    {"lat": 22.7190326, "lang": 75.9085018, "id": 2},
  ];
  static final CameraPosition _kGoogle = const CameraPosition(
    target: LatLng(19.0759837, 72.8776559),
    zoom: 14.4746,
  );
  final List<Marker> _markers = <Marker>[
    Marker(
        markerId: MarkerId('1'),
        position: LatLng(47.42796133580664, 45.885749655962),
        infoWindow: InfoWindow(
          title: 'My Position',
        )
    ),
  ];
  PolylinePoints polylinePoints = PolylinePoints();
  Map<PolylineId, Polyline> polylines = {};
  List<LatLng> polylineCoordinates = [];

  String googleAPiKey = "Please provide your api key";


  Future<Position> getUserCurrentLocation() async {
    await Geolocator.requestPermission().then((value){
    }).onError((error, stackTrace) async {
      await Geolocator.requestPermission();
      print("ERROR"+error.toString());
    });
    return await Geolocator.getCurrentPosition();
  }
  void initState() {
    super.initState();

    _getPolyline();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:AgentColor.appbarbackgroundColor,
        title: Text('Track Bus',style: MyGoogeFont.mydmSans),
        actions: [
          PopupMenuButton<int>(
            itemBuilder: (context) {
              return <PopupMenuEntry<int>>[
                const PopupMenuItem(child: Text('0'), value: 0),
                const PopupMenuItem(child: Text('1'), value: 1),
              ];
            },
          ),
        ],
      ),
      body: Container(
        child: SafeArea(

          child: GoogleMap(

            initialCameraPosition: _kGoogle,

            markers: Set<Marker>.of(_markers),
            tiltGesturesEnabled: true,
            mapType: MapType.normal,

            myLocationEnabled: true,
            polylines:Set<Polyline>.of(polylines.values),
            compassEnabled: true,

            onMapCreated: (GoogleMapController controller){
              _controller.complete(controller);
            },
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () async{
          getUserCurrentLocation().then((value) async {
            print(value.latitude.toString() +" "+value.longitude.toString());

            _markers.add(
                Marker(
                  markerId: MarkerId("2"),
                  position: LatLng(value.latitude, value.longitude),
                  infoWindow: InfoWindow(
                    title: 'My Current Location',
                    onTap: (){

                    }
                  ),
                  icon: BitmapDescriptor.defaultMarker,
                )
            );


            CameraPosition cameraPosition = new CameraPosition(
              target: LatLng(value.latitude, value.longitude),
              zoom: 14,
            );

            final GoogleMapController controller = await _controller.future;
            controller.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
            setState(() {
            });
          });
        },
        child: Icon(Icons.local_activity),
      ),
    );
  }
  _addPolyLine() {
    PolylineId id = PolylineId("poly");
    Polyline polyline = Polyline(
        polylineId: id, color: Colors.red, points: polylineCoordinates);
    polylines[id] = polyline;
    setState(() {});
  }

 void _getPolyline() async {
   for(var i=0; i<data.length; i++){}
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleAPiKey,

        PointLatLng(19.0759837, 72.8776559),
        PointLatLng(47.42796133580664, 45.885749655962),
        travelMode: TravelMode.driving,
        wayPoints: [PolylineWayPoint(location: "indore")]);
    if (result.points.isNotEmpty) {
      result.points.forEach((PointLatLng point) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
    }
    _addPolyLine();
  }
  address() {

  }
}
