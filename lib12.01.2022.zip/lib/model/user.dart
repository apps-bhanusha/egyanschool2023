import 'package:flutter/material.dart';

class User {
  final String username;

  final String fromdate;
  final String todate;
  final String reason;
  final String userfile;

  User(this.username, this.fromdate, this.todate, this.reason, this.userfile);





}
